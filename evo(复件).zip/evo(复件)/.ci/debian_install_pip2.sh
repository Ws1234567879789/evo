#!/bin/bash

set -e

apt update
apt install -y python-pip
