#!/bin/bash

set -e

apt update
apt install -y python3-pip
