These files are here just for comparing and testing.

They have been ported to support also Python 3.
Apart from that, the functionality is the same as in the original files.

Source: https://vision.in.tum.de/data/datasets/rgbd-dataset/tools
